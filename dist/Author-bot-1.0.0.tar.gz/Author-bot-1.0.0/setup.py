from setuptools import find_packages, setup

setup(
    name='Author-bot',
    version='1.0.0',
    author='alissa',
    author_email='alissa.adornato@gmail.com',
    url='https://author-bot.azurewebsites.net/',
    packages=find_packages()
)